# CourseApp: Assignment 0

## Authors
* Firstname McLastname, ID number
* Firstnamey Lastnameson, ID number

## Notes

### Implementation Summary
Short summary of your implementation, including data structures used, design choices made, and
a short tour of the class hierarchy you created.

### Testing Summary
Short summary describing the ways you chose to test your code.

### Difficulties
Please list any technological difficulties you had while working on this assignment, especially
with the tools used: Kotlin, JUnit, MockK, and Gradle.

### Feedback
Put any feedback you may have for this assignment here. This **will** be read by the course staff,
and may influence future assignments!