package il.ac.technion.cs.softwaredesign

import dev.misfitlabs.kotlinguice4.KotlinModule

class CourseTorrentModule : KotlinModule() {
    override fun configure() = TODO("Implement me!")
}