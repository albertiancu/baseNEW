package il.ac.technion.cs.softwaredesign.exceptions

class TrackerException(message: String) : Exception(message)